Qustion 1
1.This code is saved in q1.py
2.This program allows the user to input the final account value, annual interest rate (the unit is %) and the number of years.
These numbers should be positive real numbers.
The output would be the initial value of money that has to be saved to obtain the final account value.
If the user fails to input a qualified number, the user will receive a reminder and be asked to input again until the qualified number appears.
3.Execute as followings:
Enter the final account value:10000
Enter the annual interest rate:2.3
Enter the number of years:5
The initial value is: 8925.279628922432

Qustion 2
1.This code is saved in q2.py
2.This program allows the user to input an integer.
The output would be each of its numbers one by one.
3.Execute as followings:
Enter an integer:-121090642
1
2
1
0
9
0
6
4
2

Question 3
1.This code is saved in q3.py
2.This program allows the user to input a positive integer m.
The output would be the smallest integer n such that n^2 is greater than m.
3.Execute as followings:
Please enter a postive integer:134
The required smallest integer n: 12

Question 4
1.This code is saved in q4.py
2.This program allows the user to input a positive  integer  N.
The output would be a table with N rows and 3 columns. In the mth row, there are three numbers: m, m+1, and m^(m+1)
If the user fails to input a qualified number, the user will receive a reminder and be asked to input again until the qualified number appears.
3.Execute as followings:
PLease enter a positive integer:11
m        m+1      m**(m+1)
1        2        1
2        3        8
3        4        81
4        5        1024
5        6        15625
6        7        279936
7        8        5764801
8        9        134217728
9        10       3486784401
10       11       100000000000
11       12       3138428376721

Question 5
1.This code is saved in q5.py
2.This program allows the user to input a positive  integer  N.
The output would be all the prime numbers which are smaller than N with at most 8 prime numbers in each line.
If the user fails to input a qualified number, the user will receive a reminder and be asked to input again until the qualified number appears.
3.Execute as followings:
PLease enter a positive integer:78
The prime numbers smaller than 78 include:
2       3       5       7       11      13      17      19
23      29      31      37      41      43      47      53
59      61      67      71      73

Question 6
1.This code is saved in q6.py
2.This program allows the user to input a function f(x), a real interval [a, b]， the number of sub-intervals into which the interval [a, b] will be divided.
The function can only be sin, cos or tan. The number n should be a positive integer.
If the user fails to input a qualified thing, the user will receive a reminder and be asked to input again until the qualified thing appears.
3.Execute as followings:
Enter a trigonometric function (sin, cos, tan):tan
Enter lower bound a:-2
Enter higher bound b:10
Enter the number of sub-intervals n:100
14.529726766582709