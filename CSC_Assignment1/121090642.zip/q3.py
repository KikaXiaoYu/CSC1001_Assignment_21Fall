m=int(input("Please enter a postive integer:"))
n=0
while n**2<=m:
    n=n+1
print("The required smallest integer n:",n)